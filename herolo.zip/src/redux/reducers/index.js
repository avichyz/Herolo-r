import { ADD_BOT, SELECT_BOT, FILTER_BOTS } from '../actions/actionTypes';
import { initialData } from '../../MOCK_DATA';

let initialState = initialData;

function botApp(state = initialData, action) {
  switch (action.type) {
    case SELECT_BOT:
      return Object.assign({}, state, {
        selectedId: action.id
      })

    case FILTER_BOTS:
      return Object.assign({}, state, {
        searchText: action.searchText
      })

    case ADD_BOT:
      return Object.assign({}, state, {
        bots: [
          ...state.bots,
          {
            id: new Date().getUTCMilliseconds(), // getting a unique id based on a timestamp
            first_name: action.first_name,
            last_name: action.last_name,
            country: action.country,
            email: action.email,
            avatar: action.avatar,
            description: action.description
          }
        ]
      })
    default:
      return state
  }
}



export default botApp;
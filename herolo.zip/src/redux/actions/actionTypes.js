
export const ADD_BOT = 'ADD_BOT';
export const SELECT_BOT = 'SELECT_BOT';
export const FILTER_BOTS = 'FILTER_BOTS';
export const REMOVE_BOT = 'REMOVE_BOT';


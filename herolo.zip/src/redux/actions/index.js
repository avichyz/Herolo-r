
import { ADD_BOT, SELECT_BOT, FILTER_BOTS } from './actionTypes';


export function addBot(first_name, last_name, country, email, description, avatar) {
  return { type: ADD_BOT, first_name, last_name, country, email, description, avatar }
}

export function selectBot(id) {
  return { type: SELECT_BOT, id }
}

export function filterBots(searchText) {
  return { type: FILTER_BOTS, searchText }
}


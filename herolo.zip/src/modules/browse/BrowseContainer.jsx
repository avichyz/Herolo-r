import React, { Component } from 'react';
import { connect } from 'react-redux'
import { selectBot } from '../../redux/actions'
import Browse from './Browse';


class BrowseContainer extends Component {

    state = ({ selectedBot: null, displayedBots: this.props.bots });

    handleSelectBot = (id) => {
        this.props.onSelectBot(id);
    }

    componentDidUpdate(prevProps) {
        if (this.props.selectedId != prevProps.selectedId) {
            this.setState({ selectedBot: this.props.bots.find(bot => bot.id === this.props.selectedId) })
        }

        if (this.props.searchText != prevProps.searchText) {
            this.setState({
                displayedBots: this.props.bots
                    .filter(bot => (`${bot.first_name} ${bot.first_name}`
                        .toLowerCase()
                        .includes(this.props.searchText.toLowerCase())))
            })
        }
    }

    render() {
        const { selectedId } = this.props;
        const selectedBot = this.state ? this.state.selectedBot : null;
        const selectedTitle = selectedBot ? `${selectedBot.first_name} ${selectedBot.last_name}` : null;
        const selectedCountry = selectedBot ? selectedBot.country : null;
        const selectedEmail = selectedBot ? selectedBot.email : null;
        const selectedAvatar = selectedBot ? selectedBot.avatar : null;
        const selectedInfo = selectedBot ? selectedBot.description : null;


        return (
            <Browse
                bots={this.state.displayedBots}
                selectedId={selectedId}
                selectedCountry={selectedCountry}
                selectedEmail={selectedEmail}
                selectedTitle={selectedTitle}
                selectedInfo={selectedInfo}
                selectedAvatar={selectedAvatar}
                handleSelectBot={this.handleSelectBot} />
        )
    }
}

const mapStateToProps = state => ({
    bots: state.bots,
    selectedId: state.selectedId,
    searchText: state.searchText
})

const mapDispatchToProps = dispatch => ({
    onSelectBot: id => dispatch(selectBot(id))
})

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(BrowseContainer)

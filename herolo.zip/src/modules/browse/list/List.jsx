import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Card from '@material-ui/core/Card';
import ListItem from './ListItem';
import styles from './list.scss';

class List extends Component {
    static propTypes = {
        bots: PropTypes.array,
        handleSelectBot: PropTypes.func
    }

    render() {
        const { bots, handleSelectBot } = this.props;

        return (
            <Card>
                <ul className={styles.list}>
                    {
                        bots.map((bot, index) => 
                            <ListItem
                                key={bot.id}
                                id={bot.id}
                                title={`${bot.first_name} ${bot.first_name}`}
                                avatar={bot.avatar}
                                info={bot.description}
                                handleSelectBot={handleSelectBot}/>
                        )
                    }
                </ul>
            </Card>
        )
    }
}

export default List;
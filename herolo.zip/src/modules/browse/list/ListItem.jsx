import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import styles from './listItem.scss';

class ListItem extends Component {

    static propTypes = {
        id: PropTypes.number,
        title: PropTypes.string,
        avatar: PropTypes.string,
        info: PropTypes.string
    };

    handleSelectBot = () => {
        const { handleSelectBot, id } = this.props;
        handleSelectBot(id);
    }

    render() {
        const { title, avatar, info } = this.props;
        return (
            <Fragment>
                <div
                    className={styles.itemContainer}
                    onClick={this.handleSelectBot}>
                    <img
                        className={styles.img}
                        src={avatar}
                        alt="example">
                    </img>
                    <div className={styles.textContainer}>
                        <div className={styles.title}>
                            {title}
                        </div>
                        <div className={styles.textInfo}>
                            {info}
                        </div>
                    </div>
                </div>
                <hr></hr>
            </Fragment>
        )
    }
}

export default ListItem;
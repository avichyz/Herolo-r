import React, { Component } from 'react';
import PropTypes from 'prop-types';
import styles from './itemDisplay.scss';

class ItemDisplay extends Component {

    static proptypes = {
        name: PropTypes.string,
        id: PropTypes.number,
        country: PropTypes.string,
        email: PropTypes.string,
        info: PropTypes.string,
        avatar: PropTypes.string
    }

    render() {

        const {name, id, country, email, info, avatar } = this.props;

        return (
            <div className={styles.container}>
                <img
                    className={styles.img}
                    src={avatar}>
                </img>
                <div className={styles.name}>
                {name}
                </div>
                <div className={styles.id}>
                    {`id: ${id}`}
                </div>
                <div className={styles.country}>
                    {`country: ${country}`}
                </div>
                <div className={styles.email}>
                    {`email: ${email}`}
                </div>
                <div className={styles.info}>
                    {info}
                </div>
            </div>
        )
    }
}

export default ItemDisplay;
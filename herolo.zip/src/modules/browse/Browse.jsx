import React, { Component } from 'react';
import PropTypes from 'prop-types';
import styles from './browse.scss';
import Header from './header/Header';
import List from './list/List';
import ItemDisplay from './itemDispaly/ItemDisplay'
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';

class Browse extends Component {
    static propTypes = {
        bots: PropTypes.array,
        selectedId: PropTypes.number,
        selectedCountry: PropTypes.string,
        selectedEmail: PropTypes.string,
        selectedTitle: PropTypes.string,
        selectedInfo: PropTypes.string,
        selectedAvatar: PropTypes.string,
        handleSelectBot: PropTypes.func
    }

    render() {
        const {
            bots,
            handleSelectBot,
            selectedId,
            selectedCountry,
            selectedEmail,
            selectedTitle,
            selectedAvatar,
            selectedInfo } = this.props;

        return (
            <Card className={styles.root}>
                <Header botsCount={bots.length}/>
                <CardContent className={styles.card}>
                    <div className={styles.listAndItemDisplay}>
                        {
                            selectedId &&
                            <ItemDisplay
                                id={selectedId}
                                name={selectedTitle}
                                country={selectedCountry}
                                email={selectedEmail}
                                avatar={selectedAvatar}
                                info={selectedInfo} /> ||
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9bNb_ns-WzO8yoiySwYxprGkarS9-PIgPxsAX_gG0HcQl2_uu0Q">
                            </img>
                        }
                        <List
                            bots={bots}
                            handleSelectBot={handleSelectBot} />
                    </div>
                </CardContent>
            </Card>
        )
    }
}

export default Browse;
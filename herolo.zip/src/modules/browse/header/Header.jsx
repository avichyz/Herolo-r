import React, { Component } from 'react';
import PropTypes from 'prop-types';
import styles from './header.scss';
import SearchContainer from './search/SearchContainer';


class Header extends Component {
    static proptypes = {
        botsCount: PropTypes.number
    }

    render() {

        const {botsCount} = this.props;

        return (
            <div className={styles.headerContainer}>  
                <div className={styles.title}>
                    Browse our bots 
                </div>
                <SearchContainer
                botsCount={botsCount}/>
            </div>
        )
    }
}

export default Header;
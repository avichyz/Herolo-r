import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { filterBots } from '../../../../redux/actions'
import { connect } from 'react-redux'
import Search from './Search';

class SearchContainer extends Component {

    static propTypes = {
        botsCount: PropTypes.number
    }

    handleFilter = (text) => {
        this.props.onFilterBots(text);
    }

    render() {
        const {botsCount} = this.props;

        return (
            <Search
                botsCount={botsCount}
                handleFilter={this.handleFilter} />
        )
    }
}

const mapDispatchToProps = dispatch => ({
    onFilterBots: searchText => dispatch(filterBots(searchText))
})

export default connect(
    null,
    mapDispatchToProps
)(SearchContainer)


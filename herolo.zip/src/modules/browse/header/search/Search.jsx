import React, { Component } from 'react';
import PropTypes from 'prop-types';
import TextField from '@material-ui/core/TextField';
import styles from './search.scss';

class Search extends Component {

    static propTypes = {
        botsCount: PropTypes.number,
        handleFilter: PropTypes.func
    }

    
    constructor(props) {
        super(props)
        this.handleTextFieldChange = this.handleTextFieldChange.bind(this);
        this.handleFilter = this.handleFilter.bind(this);

        this.state = { searchText: "" };
    }

    handleTextFieldChange(e) {
        this.setState({
            searchText: e.target.value
        })
    }

    handleFilter(event) {
        if (event.key === 'Enter') {
            this.props.handleFilter(this.state.searchText)
            event.preventDefault();
        }
    }

    render() {
        const { botsCount } = this.props;

        return (
            <div>
                {`${botsCount ? botsCount : 0} bots filtered`}
                <TextField
                    className={styles.searchBox}
                    id="standard"
                    label="search text"
                    margin="normal"
                    onKeyPress={this.handleFilter}
                    onChange={this.handleTextFieldChange}
                />
            </div>
        )
    }
}

export default Search;
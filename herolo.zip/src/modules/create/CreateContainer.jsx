import React from 'react';
import { connect } from 'react-redux'
import { addBot} from '../../redux/actions';
import Create from './Create';

class CreateContainer extends React.Component {

    // handleSaveNewBot = (values) => {
    //     const { first_name, last_name, email, country, description, avatar } = this.state;
    //     this.props.handleSaveNewBot(first_name, last_name, email, country, description, avatar);
    // }
    
    render() {
        return (
            <Create 
            handleSaveNewBot={this.props.saveNewBot}
            />
        );
    }
}


const mapDispatchToProps = dispatch => ({
    saveNewBot: (first_name, last_name, email, country, description, avatar) => 
    dispatch(addBot(first_name, last_name, email, country, description, avatar))
})

export default connect(
    null,
    mapDispatchToProps
)(CreateContainer)

import React from 'react';
import PropTypes from 'prop-types';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import AddIcon from '@material-ui/icons/Add';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import styles from './create.scss';
import { MuiThemeProvider } from '@material-ui/core';


class Create extends React.Component {

    state = {
        first_name: "",
        last_name: "",
        email: "",
        country: "",
        description: "",
        avatar: ""
    }

    handleChange = name => event => {
        this.setState({
            [name]: event.target.value,
        });
    };

    handleSaveNewBot = (event) => {
        event.preventDefault();
        const { first_name, last_name, email, country, description, avatar } = this.state;
        this.props.handleSaveNewBot(first_name, last_name, email, country, description, avatar);
    }

    render() {
        return (
            <Card className={styles.root}>
                <CardContent>
                    <form
                        noValidate
                        autoComplete="off"
                        className={styles.container}
                        onSubmit={this.handleSaveNewBot}>
                        <TextField
                            required
                            id="standard-required"
                            label="First Name"
                            onChange={this.handleChange('first_name')}
                            className={styles.textField}
                            margin="normal"
                        />

                        <TextField
                            required
                            id="standard-required"
                            label="Last Name"
                            onChange={this.handleChange('last_name')}
                            className={styles.textField}
                            margin="normal"
                        />
                        <TextField
                            required
                            id="standard-required"
                            label="Email"
                            onChange={this.handleChange('email')}
                            className={styles.textField}
                            margin="normal"
                        />
                        <TextField
                            required
                            id="standard-required"
                            label="Country"
                            onChange={this.handleChange('country')}
                            className={styles.textField}
                            margin="normal"
                        />

                        <TextField
                            id="standard-multiline-static"
                            label="Description"
                            onChange={this.handleChange('description')}
                            multiline
                            rows="4"
                            className={styles.textField}
                            margin="normal"
                        />

                        <TextField
                            required
                            id="standard-required"
                            label="Avatar"
                            onChange={this.handleChange('avatar')}
                            className={styles.textField}
                            margin="normal"
                        />
                        0/32
                        <Button
                            type="submit" label="login" className="button-submit"
                            variant="fab" color="primary" aria-label="Add">
                            <AddIcon />
                        </Button>
                    </form>
                </CardContent>
            </Card>
        );
    }
}


export default Create;
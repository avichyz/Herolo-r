import React, { Component } from 'react';
import styles from './home.scss';


class Home extends Component {
    render() {
        return (
            <div className={styles.root}>
                <div className={styles.title}>
                    Welcome Shoppers!
                </div>
                <div className={styles.imageContainer}>
                <img className={styles.botImage}
                src="https://cdn3.f-cdn.com/contestentries/322702/17676116/568bc94e013f5_thumb900.jpg" />
                </div>
            </div>
        )
    }
}

export default Home;